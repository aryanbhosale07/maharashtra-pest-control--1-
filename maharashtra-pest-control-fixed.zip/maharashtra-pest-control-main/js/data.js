/**
 * MAHARASHTRA PEST CONTROL - Data Store & Seed Information
 * Proprietor: Harshal Satkar | Contact: 7208102567
 * Email: maharashtra.pestcontrol13@gmail.com
 * Coverage: Mumbai, Navi Mumbai, Thane and nearby areas
 */

const MPC_STORAGE_KEYS = {
    BOOKINGS: 'mpc_bookings_v2',
    FEEDBACKS: 'mpc_feedbacks_v2',
    PAYMENTS: 'mpc_payments_v2',
    CURRENT_USER: 'mpc_current_user_v2',
    ADMIN_SESSION: 'mpc_admin_session_v2'
};

const COMPANY_INFO = {
    name: 'MAHARASHTRA PEST CONTROL',
    tagline: '10+ Years of Certified Pest-Free Living Across Mumbai, Navi Mumbai & Thane',
    owner: 'Harshal Satkar',
    phone: '7208102567',
    formattedPhone: '+91 7208102567',
    email: 'maharashtra.pestcontrol13@gmail.com',
    experience: '10+ Years (Established 2014)',
    coverage: ['Mumbai', 'Navi Mumbai', 'Thane', 'Mira-Bhayandar', 'Kalyan-Dombivli', 'Panvel'],
    upiId: '7208102567@upi',
    workingHours: '8:00 AM - 9:00 PM (Monday to Sunday)'
};

const PEST_TYPES = [
    {
        id: 'cockroach',
        name: 'Cockroach',
        localName: 'झेकुर / Cockroach Gel & Spray',
        icon: '🪳',
        popular: true,
        basePrice: 899,
        description: 'Advanced Odourless Gel Baiting + Herbal Micron Spray. Targets hidden nesting in kitchen cracks, pipes, & cabinets with 100% eradication.',
        warrantyDays: 365,
        treatmentMethods: ['Bayer Advanced Gel Matrix', 'Deep Pipe Flush', 'Odorless Crack Mist']
    },
    {
        id: 'termite',
        name: 'Termite',
        localName: 'वाळवी / Termite Drill-Fill-Seal',
        icon: '🪵',
        popular: true,
        basePrice: 1999,
        description: 'Heavy-duty Drill-Fill-Seal chemical barrier injection using govt-approved Termidor/Premise chemicals. Complete protection for doors, furniture & walls.',
        warrantyDays: 365,
        treatmentMethods: ['Drill-Fill-Seal Barrier', 'Wood Penetrating Oil', 'Wall Skirting Pressure Infusion']
    },
    {
        id: 'bedbug',
        name: 'Bedbug',
        localName: 'ढेकूण / Thermal & Contact Eradication',
        icon: '🛏️',
        popular: true,
        basePrice: 1499,
        description: 'Intense 2-visit eradication system destroying both live adult bugs and microscopic eggs hiding in mattress seams, bed frames, and switchboards.',
        warrantyDays: 365,
        treatmentMethods: ['High-Heat Steam Evaporation', 'Synthetic Pyrethroid Mist', 'Egg-Lethal Contact Spray']
    },
    {
        id: 'ant',
        name: 'Ant',
        localName: 'मुंग्या / Ant Colony Destruction',
        icon: '🐜',
        popular: false,
        basePrice: 799,
        description: 'Colony-elimination micro-granules and sweet-bait liquid syrup that worker ants carry back into the queen nest, neutralizing the entire colony.',
        warrantyDays: 365,
        treatmentMethods: ['Sugar & Protein Protein Bait', 'Perimeter Barrier Line', 'Crevice Dusting']
    },
    {
        id: 'rodent',
        name: 'Rodent',
        localName: 'उंदीर / Mice & Rat Eradication',
        icon: '🐀',
        popular: false,
        basePrice: 1199,
        description: 'Multi-layer trapping, tamper-resistant poison bait stations, glue repellent boards, and entry-hole burrows sealing to eliminate destructive rats.',
        warrantyDays: 365,
        treatmentMethods: ['Tamper-Proof Bait Stations', 'Super-Tack Glue Boards', 'Entry Point Burrow Sealing']
    },
    {
        id: 'comprehensive',
        name: 'All-in-One Multi-Pest AMC',
        localName: 'सर्व कीटक नियंत्रण / Complete Home AMC',
        icon: '🛡️',
        popular: true,
        basePrice: 2499,
        description: 'Comprehensive 1-Year Shield covering Cockroaches, Ants, Rodents, and Spiders with 3 free quarterly visits and unlimited emergency callouts.',
        warrantyDays: 365,
        treatmentMethods: ['4-Stage Quarterly Treatment', 'Kitchen & Washroom Shield', 'Free Recall Support']
    }
];

// Helper to format date YYYY-MM-DD
function formatDate(d) {
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
}

// Generate sample initial dates (today, yesterday, 11 months ago to demonstrate 1-year expiry notifications!)
const TODAY = new Date();
const TOMORROW = new Date(TODAY);
TOMORROW.setDate(TODAY.getDate() + 1);

const DAY_AFTER = new Date(TODAY);
DAY_AFTER.setDate(TODAY.getDate() + 2);

const ALMOST_EXPIRED_DATE = new Date(TODAY);
ALMOST_EXPIRED_DATE.setFullYear(TODAY.getFullYear() - 1);
ALMOST_EXPIRED_DATE.setDate(ALMOST_EXPIRED_DATE.getDate() + 12); // Expiry in 12 days!

const EXPIRED_DATE = new Date(TODAY);
EXPIRED_DATE.setFullYear(TODAY.getFullYear() - 1);
EXPIRED_DATE.setDate(EXPIRED_DATE.getDate() - 5); // Expired 5 days ago!

const FRESH_AMC_DATE = new Date(TODAY);
FRESH_AMC_DATE.setMonth(TODAY.getMonth() - 2); // 2 months in, 10 months remaining

// Seed Initial Bookings
const SEED_BOOKINGS = [
    {
        id: 'MPC-BK-1001',
        customerName: 'Rajesh Patil',
        phone: '9820112233',
        customerType: 'household', // household or commercial
        propertyDetails: '3 BHK Flat (1250 sq.ft), Sea View Apts',
        address: 'Flat 602, Sea View Heights, Near Shivaji Park, Dadar West',
        city: 'Mumbai',
        pestType: 'termite',
        pestName: 'Termite (Wood & Wall Drill-Fill)',
        bookingDate: formatDate(TODAY),
        slotTime: 'morning', // 'morning' (10 AM - 1 PM) or 'evening' (3 PM - 6 PM)
        slotLabel: 'Morning Slot (10:00 AM - 01:00 PM)',
        status: 'confirmed', // 'pending', 'confirmed', 'completed', 'cancelled'
        amount: 2499,
        paymentStatus: 'paid', // 'paid', 'unpaid', 'at_inspection'
        paymentMethod: 'UPI (PhonePe)',
        transactionId: 'UPI-TXN-8823901',
        serviceStartDate: formatDate(TODAY),
        validityExpiryDate: formatDate(new Date(TODAY.getFullYear() + 1, TODAY.getMonth(), TODAY.getDate())),
        warrantyActive: true,
        notes: 'Customer observed termite powder near master bedroom wardrobe.',
        serviceTrackRecord: [
            { date: formatDate(TODAY), event: 'Inspection & Comprehensive Drill-Fill-Seal treatment scheduled', technician: 'Harshal Satkar' }
        ]
    },
    {
        id: 'MPC-BK-1002',
        customerName: 'Priya Sharma',
        phone: '9819445566',
        customerType: 'household',
        propertyDetails: '2 BHK Apartment (850 sq.ft)',
        address: 'B-304, Green Meadows, Sector 19, Palm Beach Road, Vashi',
        city: 'Navi Mumbai',
        pestType: 'cockroach',
        pestName: 'Cockroach & Ant Gel Eradication',
        bookingDate: formatDate(TODAY),
        slotTime: 'evening',
        slotLabel: 'Evening Slot (03:00 PM - 06:00 PM)',
        status: 'confirmed',
        amount: 899,
        paymentStatus: 'paid',
        paymentMethod: 'Google Pay',
        transactionId: 'GPAY-7729103',
        serviceStartDate: formatDate(TODAY),
        validityExpiryDate: formatDate(new Date(TODAY.getFullYear() + 1, TODAY.getMonth(), TODAY.getDate())),
        warrantyActive: true,
        notes: 'Severe German cockroach issue in modular kitchen. Pet dog in house - odorless gel required.',
        serviceTrackRecord: [
            { date: formatDate(TODAY), event: 'Slot Confirmed for German Cockroach Bayer Gel treatment', technician: 'Siddhesh (Team MPC)' }
        ]
    },
    {
        id: 'MPC-BK-1003',
        customerName: 'Sunil Deshmukh (Saffron Spice Restaurant)',
        phone: '9892019988',
        customerType: 'commercial',
        propertyDetails: 'Restaurant & Cloud Kitchen (1800 sq.ft)',
        address: 'Shop 12-14, Galleria Arcade, Hiranandani Estate, Ghodbunder Rd',
        city: 'Thane',
        pestType: 'rodent',
        pestName: 'Rodent & Cockroach Commercial Shield',
        bookingDate: formatDate(TOMORROW),
        slotTime: 'morning',
        slotLabel: 'Morning Slot (10:00 AM - 01:00 PM)',
        status: 'confirmed',
        amount: 3500,
        paymentStatus: 'paid',
        paymentMethod: 'UPI Direct to 7208102567',
        transactionId: 'MPC-PAY-99381',
        serviceStartDate: formatDate(TOMORROW),
        validityExpiryDate: formatDate(new Date(TOMORROW.getFullYear() + 1, TOMORROW.getMonth(), TOMORROW.getDate())),
        warrantyActive: true,
        notes: 'FSSAI compliant pest control audit required. Kitchen pantry rodent proofing.',
        serviceTrackRecord: [
            { date: formatDate(TOMORROW), event: 'Commercial Inspection & Trap Deployment Slot Booked', technician: 'Harshal Satkar' }
        ]
    },
    // Seed record with EXPIRING SOON validity (12 days left) to showcase Admin Alert System
    {
        id: 'MPC-BK-0985',
        customerName: 'Anand Kulkarni',
        phone: '9820556677',
        customerType: 'household',
        propertyDetails: '3 BHK Flat (1350 sq.ft)',
        address: 'Flat 1101, Lodha Aqua, Mira Road / Dahisar Check Naka',
        city: 'Mumbai',
        pestType: 'termite',
        pestName: 'Termite Drill-Fill 1-Year AMC',
        bookingDate: formatDate(ALMOST_EXPIRED_DATE),
        slotTime: 'morning',
        slotLabel: 'Morning Slot (10:00 AM - 01:00 PM)',
        status: 'completed',
        amount: 2800,
        paymentStatus: 'paid',
        paymentMethod: 'Cash to Technician',
        transactionId: 'CASH-REC-1082',
        serviceStartDate: formatDate(ALMOST_EXPIRED_DATE),
        validityExpiryDate: formatDate(new Date(ALMOST_EXPIRED_DATE.getFullYear() + 1, ALMOST_EXPIRED_DATE.getMonth(), ALMOST_EXPIRED_DATE.getDate())),
        warrantyActive: true,
        notes: 'Wooden flooring treated. Due for 1-Year Annual Renewal.',
        serviceTrackRecord: [
            { date: formatDate(ALMOST_EXPIRED_DATE), event: 'Primary Drill-Fill Chemical Injection Completed', technician: 'Harshal Satkar' },
            { date: '2026-02-15', event: '6-Month Routine Follow-up Audit (No activity found)', technician: 'MPC Team' },
            { date: '2026-09-25', event: 'Upcoming: 1-Year AMC Expiry approaching. Renewal notice queued.', technician: 'System' }
        ]
    },
    // Seed record already EXPIRED to test expired status
    {
        id: 'MPC-BK-0940',
        customerName: 'Kavita Chougule',
        phone: '9833441122',
        customerType: 'household',
        propertyDetails: '1 BHK Apartment (580 sq.ft)',
        address: 'B-12, Everest Residency, Kopar Khairane',
        city: 'Navi Mumbai',
        pestType: 'bedbug',
        pestName: 'Bedbug 2-Stage Thermal Eradication',
        bookingDate: formatDate(EXPIRED_DATE),
        slotTime: 'evening',
        slotLabel: 'Evening Slot (03:00 PM - 06:00 PM)',
        status: 'completed',
        amount: 1499,
        paymentStatus: 'paid',
        paymentMethod: 'UPI (Paytm)',
        transactionId: 'PTM-883190',
        serviceStartDate: formatDate(EXPIRED_DATE),
        validityExpiryDate: formatDate(new Date(EXPIRED_DATE.getFullYear() + 1, EXPIRED_DATE.getMonth(), EXPIRED_DATE.getDate())),
        warrantyActive: false,
        notes: 'Bedbug treatment completed successfully. AMC expired 5 days ago.',
        serviceTrackRecord: [
            { date: formatDate(EXPIRED_DATE), event: 'Stage 1 Bedbug treatment with High Heat & Permethrin', technician: 'Harshal Satkar' },
            { date: '2025-10-25', event: 'Stage 2 Follow-up Egg eradication completed', technician: 'Harshal Satkar' }
        ]
    }
];

// Seed Customer Feedbacks
const SEED_FEEDBACKS = [
    {
        id: 'FB-101',
        name: 'Amitabh Sen',
        area: 'Bandra West, Mumbai',
        phone: '9820******',
        customerType: 'Household (3 BHK)',
        pestTreated: 'Termite & Cockroach',
        rating: 5,
        date: '2026-09-28',
        comment: 'Harshal ji personally inspected our apartment. The termite treatment was done with zero disturbance to our Italian marble flooring. It has been 6 months and not a single pest seen. Highly recommended in Mumbai!',
        verified: true
    },
    {
        id: 'FB-102',
        name: 'Dr. Sneha Vaidya',
        area: 'Vashi, Navi Mumbai',
        phone: '9819******',
        customerType: 'Dental Clinic (Commercial)',
        pestTreated: 'Cockroach & Ant Gel',
        rating: 5,
        date: '2026-10-02',
        comment: 'We run a clinic so odourless, safe chemicals were a mandatory requirement. Maharashtra Pest Control did a completely odourless gel treatment. 100% clean and professional. The 1-year warranty gives immense peace of mind.',
        verified: true
    },
    {
        id: 'FB-103',
        name: 'Vikram Shinde',
        area: 'Panchpakhadi, Thane West',
        phone: '9892******',
        customerType: 'Household (2 BHK)',
        pestTreated: 'Bedbug Eradication',
        rating: 5,
        date: '2026-09-14',
        comment: 'We were struggling with bedbugs for 3 months and tried local sprays with no luck. Harshal Satkar’s team came with proper PPE and did 2 rounds of steam and mist. Problem solved permanently. 10/10 service!',
        verified: true
    },
    {
        id: 'FB-104',
        name: 'Nilesh Ghadge',
        area: 'Belapur, Navi Mumbai',
        phone: '9769******',
        customerType: 'Corporate Office (Commercial)',
        pestTreated: 'Rodent & General Pest',
        rating: 5,
        date: '2026-08-20',
        comment: 'Annual Maintenance Contract for our 3,000 sq ft office. Timely quarterly visits, transparent billing to 7208102567, and prompt WhatsApp response whenever we need a follow up.',
        verified: true
    }
];

// Seed Payments Log
const SEED_PAYMENTS = [
    {
        id: 'TXN-MPC-901',
        bookingId: 'MPC-BK-1001',
        customerName: 'Rajesh Patil',
        customerPhone: '9820112233',
        amount: 2499,
        method: 'UPI (PhonePe)',
        adminPhone: '7208102567',
        status: 'SUCCESS',
        date: '2026-10-10 10:14 AM',
        utr: 'UTR-9820112233-PHN',
        note: 'Pre-payment for Termite 1-Year AMC'
    },
    {
        id: 'TXN-MPC-902',
        bookingId: 'MPC-BK-1002',
        customerName: 'Priya Sharma',
        customerPhone: '9819445566',
        amount: 899,
        method: 'Google Pay',
        adminPhone: '7208102567',
        status: 'SUCCESS',
        date: '2026-10-10 09:30 AM',
        utr: 'UTR-GPAY-981944',
        note: 'Pre-payment for Cockroach Gel Treatment'
    },
    {
        id: 'TXN-MPC-903',
        bookingId: 'MPC-BK-1003',
        customerName: 'Sunil Deshmukh',
        customerPhone: '9892019988',
        amount: 3500,
        method: 'UPI Direct',
        adminPhone: '7208102567',
        status: 'SUCCESS',
        date: '2026-10-09 04:45 PM',
        utr: 'UTR-MPC-3500-DESH',
        note: 'Commercial Cloud Kitchen Rodent AMC'
    }
];

// Storage Helper Functions
const MPCStore = {
    getBookings() {
        try {
            const data = localStorage.getItem(MPC_STORAGE_KEYS.BOOKINGS);
            if (!data) {
                localStorage.setItem(MPC_STORAGE_KEYS.BOOKINGS, JSON.stringify(SEED_BOOKINGS));
                return SEED_BOOKINGS;
            }
            return JSON.parse(data);
        } catch (e) {
            console.error('Error fetching bookings:', e);
            return SEED_BOOKINGS;
        }
    },

    saveBookings(bookings) {
        localStorage.setItem(MPC_STORAGE_KEYS.BOOKINGS, JSON.stringify(bookings));
    },

    addBooking(booking) {
        const bookings = this.getBookings();
        bookings.unshift(booking);
        this.saveBookings(bookings);
        return booking;
    },

    updateBooking(id, updates) {
        const bookings = this.getBookings();
        const index = bookings.findIndex(b => b.id === id);
        if (index !== -1) {
            bookings[index] = { ...bookings[index], ...updates };
            this.saveBookings(bookings);
            return bookings[index];
        }
        return null;
    },

    getFeedbacks() {
        try {
            const data = localStorage.getItem(MPC_STORAGE_KEYS.FEEDBACKS);
            if (!data) {
                localStorage.setItem(MPC_STORAGE_KEYS.FEEDBACKS, JSON.stringify(SEED_FEEDBACKS));
                return SEED_FEEDBACKS;
            }
            return JSON.parse(data);
        } catch (e) {
            return SEED_FEEDBACKS;
        }
    },

    addFeedback(fb) {
        const feedbacks = this.getFeedbacks();
        feedbacks.unshift(fb);
        localStorage.setItem(MPC_STORAGE_KEYS.FEEDBACKS, JSON.stringify(feedbacks));
        return fb;
    },

    getPayments() {
        try {
            const data = localStorage.getItem(MPC_STORAGE_KEYS.PAYMENTS);
            if (!data) {
                localStorage.setItem(MPC_STORAGE_KEYS.PAYMENTS, JSON.stringify(SEED_PAYMENTS));
                return SEED_PAYMENTS;
            }
            return JSON.parse(data);
        } catch (e) {
            return SEED_PAYMENTS;
        }
    },

    addPayment(payment) {
        const payments = this.getPayments();
        payments.unshift(payment);
        localStorage.setItem(MPC_STORAGE_KEYS.PAYMENTS, JSON.stringify(payments));
        return payment;
    },

    getCurrentUser() {
        try {
            const user = localStorage.getItem(MPC_STORAGE_KEYS.CURRENT_USER);
            return user ? JSON.parse(user) : null;
        } catch (e) {
            return null;
        }
    },

    setCurrentUser(user) {
        if (!user) {
            localStorage.removeItem(MPC_STORAGE_KEYS.CURRENT_USER);
        } else {
            localStorage.setItem(MPC_STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
        }
    },

    ADMIN_AUTH: { user: 'harshal', salt: '5d0d27e801c8f747', hash: '96ab8478dac8d277a204b4fef914e744929da848b0165cabbdc9bc5928c46b6f' },

    async verifyAdmin(u, p) {
        const a = this.ADMIN_AUTH;
        const buf = new TextEncoder().encode(`${a.salt}:${(u || '').trim().toLowerCase()}:${p || ''}`);
        const dig = await crypto.subtle.digest('SHA-256', buf);
        const hex = Array.from(new Uint8Array(dig)).map(b => b.toString(16).padStart(2, '0')).join('');
        return hex === a.hash;
    },

    isAdminLoggedIn() {
        try {
            const exp = parseInt(sessionStorage.getItem(MPC_STORAGE_KEYS.ADMIN_SESSION) || '0', 10);
            return exp > Date.now();
        } catch (e) { return false; }
    },

    setAdminLoggedIn(status) {
        try {
            localStorage.removeItem(MPC_STORAGE_KEYS.ADMIN_SESSION); // clear old permanent flag
            if (status) sessionStorage.setItem(MPC_STORAGE_KEYS.ADMIN_SESSION, String(Date.now() + 30 * 60 * 1000));
            else sessionStorage.removeItem(MPC_STORAGE_KEYS.ADMIN_SESSION);
        } catch (e) {}
    },

    // Check slot availability for a specific date
    // Max 2 slots per day rule: 'morning' and 'evening'
    getSlotAvailability(dateStr) {
        const bookings = this.getBookings();
        const activeBookings = bookings.filter(b => b.bookingDate === dateStr && b.status !== 'cancelled');

        const morningBooked = activeBookings.some(b => b.slotTime === 'morning');
        const eveningBooked = activeBookings.some(b => b.slotTime === 'evening');
        const totalBooked = (morningBooked ? 1 : 0) + (eveningBooked ? 1 : 0);

        return {
            date: dateStr,
            totalBooked,
            maxSlots: 2,
            slotsRemaining: Math.max(0, 2 - totalBooked),
            isFullyBooked: totalBooked >= 2,
            morning: {
                time: 'morning',
                label: 'Slot 1: Morning (10:00 AM - 01:00 PM)',
                isAvailable: !morningBooked,
                bookedBy: morningBooked ? activeBookings.find(b => b.slotTime === 'morning')?.customerName : null
            },
            evening: {
                time: 'evening',
                label: 'Slot 2: Evening (03:00 PM - 06:00 PM)',
                isAvailable: !eveningBooked,
                bookedBy: eveningBooked ? activeBookings.find(b => b.slotTime === 'evening')?.customerName : null
            }
        };
    },

    // Get list of customers whose 1-year validity is expiring within 30 days or already expired
    getExpiringCustomers() {
        const bookings = this.getBookings();
        const now = new Date();
        const thirtyDaysAhead = new Date();
        thirtyDaysAhead.setDate(now.getDate() + 30);

        return bookings.filter(b => {
            if (!b.validityExpiryDate) return false;
            const exp = new Date(b.validityExpiryDate);
            // Include expired or expiring within 30 days
            return exp <= thirtyDaysAhead;
        }).map(b => {
            const exp = new Date(b.validityExpiryDate);
            const diffTime = exp - now;
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
            return {
                ...b,
                daysRemaining: diffDays,
                isExpired: diffDays < 0,
                isUrgent: diffDays >= 0 && diffDays <= 15
            };
        }).sort((a, b) => a.daysRemaining - b.daysRemaining);
    }
};

window.MPCStore = MPCStore;
window.COMPANY_INFO = COMPANY_INFO;
window.PEST_TYPES = PEST_TYPES;
