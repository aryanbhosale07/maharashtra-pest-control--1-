/**
 * MAHARASHTRA PEST CONTROL - Core Application Engine
 * Proprietor: Harshal Satkar | 7208102567 | maharashtra.pestcontrol13@gmail.com
 * Mumbai • Navi Mumbai • Thane
 */

document.addEventListener('DOMContentLoaded', () => {
    MPCApp.init();
});

const MPCApp = {
    currentMode: 'customer', // 'customer' or 'admin'
    selectedPest: 'cockroach',
    selectedPropertyType: 'household', // 'household' or 'commercial'
    selectedSlot: 'morning',
    selectedDate: '',
    selectedPaymentMode: 'at_inspection', // 'prepay_upi' or 'at_inspection'
    pendingOtp: null,
    pendingOtpType: null, // 'user_login', 'booking_verify', 'admin_login'
    pendingOtpPhone: null,
    pendingBookingPayload: null,

    init() {
        this.selectedDate = formatDate(new Date());
        this.cacheDOM();
        this.bindEvents();
        this.renderPestOptions();
        this.renderReviewsList();
        this.updateDateAndSlotsAvailability(this.selectedDate);
        this.checkInitialSession();
        this.setupAudioChime();
        this.renderAdminDashboard();
    },

    cacheDOM() {
        // Views
        this.customerView = document.getElementById('customer-view');
        this.adminView = document.getElementById('admin-view');
        this.portalSwitchBtn = document.getElementById('portal-switch-btn');
        this.portalSwitchText = document.getElementById('portal-switch-text');

        // Nav & Auth
        this.userAuthBtn = document.getElementById('user-auth-btn');
        this.authBtnText = document.getElementById('auth-btn-text');

        // Hero Slot Preview
        this.heroDateLabel = document.getElementById('hero-date-label');
        this.heroMorningStatus = document.getElementById('hero-morning-status');
        this.heroEveningStatus = document.getElementById('hero-evening-status');

        // Booking Elements
        this.premiseHouseholdBtn = document.getElementById('premise-household');
        this.premiseCommercialBtn = document.getElementById('premise-commercial');
        this.commercialFieldGroup = document.getElementById('commercial-field-group');
        this.propertySizeLabel = document.getElementById('property-size-label');
        this.bookingDatePicker = document.getElementById('booking-date');
        this.slotMorningCard = document.getElementById('slot-morning-card');
        this.slotEveningCard = document.getElementById('slot-evening-card');
        this.slotMorningStatus = document.getElementById('slot-morning-status');
        this.slotEveningStatus = document.getElementById('slot-evening-status');
        this.slotsRemainingBadge = document.getElementById('slots-remaining-badge');
        this.fullyBookedWarning = document.getElementById('fully-booked-warning');
        this.bookingSubmitBtn = document.getElementById('booking-submit-btn');
        this.bookingForm = document.getElementById('inspection-booking-form');
        this.bookingCustomerPhone = document.getElementById('cust-phone');
        this.phoneVerifyBadge = document.getElementById('phone-verify-badge');

        // Prepayment Radio
        this.payRadioPrepay = document.getElementById('pay-prepay');
        this.payRadioLater = document.getElementById('pay-later');

        // Modals
        this.otpModal = document.getElementById('otp-modal');
        this.otpModalTitle = document.getElementById('otp-modal-title');
        this.otpModalPhone = document.getElementById('otp-modal-phone');
        this.otpInput1 = document.getElementById('otp-digit-1');
        this.otpInput2 = document.getElementById('otp-digit-2');
        this.otpInput3 = document.getElementById('otp-digit-3');
        this.otpInput4 = document.getElementById('otp-digit-4');
        this.otpSubmitBtn = document.getElementById('otp-submit-btn');

        // SMS Toast Simulator
        this.smsToast = document.getElementById('sms-toast-simulator');
        this.smsRecipient = document.getElementById('sms-recipient');
        this.smsMessage = document.getElementById('sms-message');
        this.smsAutofillBtn = document.getElementById('sms-autofill-btn');

        // Payment QR Modal
        this.paymentModal = document.getElementById('payment-modal');
        this.payModalAmount = document.getElementById('pay-modal-amount');
        this.payModalBookingId = document.getElementById('pay-modal-booking-id');

        // Warranty Lookup & Card
        this.amcSearchInput = document.getElementById('amc-search-input');
        this.amcSearchBtn = document.getElementById('amc-search-btn');
        this.warrantyResultContainer = document.getElementById('warranty-result-container');

        // Feedback
        this.feedbackForm = document.getElementById('feedback-form');
        this.feedbackStars = document.querySelectorAll('.star-btn');
        this.selectedRating = 5;

        // Admin Elements
        this.adminBookingsCount = document.getElementById('admin-bookings-count');
        this.adminTodaySlotsCount = document.getElementById('admin-today-slots');
        this.adminActiveAmcCount = document.getElementById('admin-active-amc');
        this.adminPaymentsCount = document.getElementById('admin-payments-count');
        this.adminExpiryAlertsContainer = document.getElementById('admin-expiry-alerts-container');
        this.adminExpiryBadge = document.getElementById('admin-expiry-badge');
        this.adminBookingsTableBody = document.getElementById('admin-bookings-tbody');
        this.adminPaymentsTableBody = document.getElementById('admin-payments-tbody');
        this.adminFeedbackTableBody = document.getElementById('admin-feedbacks-tbody');
    },

    bindEvents() {
        // Portal Switch
        this.portalSwitchBtn.addEventListener('click', () => {
            if (this.currentMode === 'customer') {
                this.requestAdminAccess();
            } else {
                this.switchPortal('customer');
            }
        });

        // User Auth
        this.userAuthBtn.addEventListener('click', () => {
            const user = MPCStore.getCurrentUser();
            if (user) {
                if (confirm(`Logged in as ${user.name || user.phone}. Do you want to sign out?`)) {
                    MPCStore.setCurrentUser(null);
                    this.checkInitialSession();
                    this.showToast('Logged out successfully');
                }
            } else {
                this.openOtpModal('user_login', '');
            }
        });

        // Household vs Commercial Switcher
        this.premiseHouseholdBtn.addEventListener('click', () => this.setPropertyType('household'));
        this.premiseCommercialBtn.addEventListener('click', () => this.setPropertyType('commercial'));

        // Booking Date Change
        if (this.bookingDatePicker) {
            this.bookingDatePicker.value = this.selectedDate;
            this.bookingDatePicker.min = formatDate(new Date());
            this.bookingDatePicker.addEventListener('change', (e) => {
                this.selectedDate = e.target.value;
                this.updateDateAndSlotsAvailability(this.selectedDate);
            });
        }

        // Slot Cards Select
        this.slotMorningCard.addEventListener('click', () => {
            if (!this.slotMorningCard.classList.contains('disabled')) {
                this.selectSlot('morning');
            }
        });

        this.slotEveningCard.addEventListener('click', () => {
            if (!this.slotEveningCard.classList.contains('disabled')) {
                this.selectSlot('evening');
            }
        });

        // Payment Radio Switch
        const radioCards = document.querySelectorAll('.payment-radio-box');
        radioCards.forEach(card => {
            card.addEventListener('click', () => {
                radioCards.forEach(c => c.classList.remove('active'));
                card.classList.add('active');
                const radio = card.querySelector('input[type="radio"]');
                radio.checked = true;
                this.selectedPaymentMode = radio.value;
            });
        });

        // Booking Form Submit
        this.bookingForm.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleBookingSubmission();
        });

        // OTP inputs auto-advance
        [this.otpInput1, this.otpInput2, this.otpInput3, this.otpInput4].forEach((input, idx, arr) => {
            input.addEventListener('input', (e) => {
                if (e.target.value.length === 1 && idx < arr.length - 1) {
                    arr[idx + 1].focus();
                }
            });
            input.addEventListener('keydown', (e) => {
                if (e.key === 'Backspace' && !e.target.value && idx > 0) {
                    arr[idx - 1].focus();
                }
            });
        });

        // OTP Submit
        this.otpSubmitBtn.addEventListener('click', () => this.verifyEnteredOtp());

        // SMS Autofill button
        this.smsAutofillBtn.addEventListener('click', () => {
            if (this.pendingOtp) {
                const digits = String(this.pendingOtp).split('');
                if (digits.length === 4) {
                    this.otpInput1.value = digits[0];
                    this.otpInput2.value = digits[1];
                    this.otpInput3.value = digits[2];
                    this.otpInput4.value = digits[3];
                    this.playChime(600);
                    this.verifyEnteredOtp();
                }
            }
        });

        // AMC Search
        this.amcSearchBtn.addEventListener('click', () => {
            this.handleWarrantyLookup();
        });
        this.amcSearchInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.handleWarrantyLookup();
        });

        // Feedback Stars
        this.feedbackStars.forEach(btn => {
            btn.addEventListener('click', () => {
                const rating = parseInt(btn.dataset.rating, 10);
                this.selectedRating = rating;
                this.feedbackStars.forEach(s => {
                    const r = parseInt(s.dataset.rating, 10);
                    s.classList.toggle('active', r <= rating);
                });
            });
        });

        // Feedback Form Submit
        this.feedbackForm.addEventListener('submit', (e) => {
            e.preventDefault();
            this.handleFeedbackSubmission();
        });

        // Admin Tab Switchers
        const adminTabs = document.querySelectorAll('.admin-tab-btn');
        adminTabs.forEach(tab => {
            tab.addEventListener('click', () => {
                adminTabs.forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                const targetId = tab.dataset.target;
                document.querySelectorAll('.admin-tab-content').forEach(c => c.style.display = 'none');
                const targetContent = document.getElementById(targetId);
                if (targetContent) targetContent.style.display = 'block';
            });
        });

        // Modal close buttons
        document.querySelectorAll('.modal-close-btn, .close-modal-trigger').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('active'));
            });
        });

        // Close on clicking overlay backdrop
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) {
                    overlay.classList.remove('active');
                }
            });
        });
    },

    setupAudioChime() {
        // Audio synthesis using Web Audio API (smooth modern audio cues without external assets)
        try {
            window.AudioContext = window.AudioContext || window.webkitAudioContext;
            this.audioCtx = new AudioContext();
        } catch (e) {
            console.warn('Web Audio not supported');
        }
    },

    playChime(freq = 520, type = 'sine') {
        if (!this.audioCtx) return;
        try {
            if (this.audioCtx.state === 'suspended') {
                this.audioCtx.resume();
            }
            const osc = this.audioCtx.createOscillator();
            const gain = this.audioCtx.createGain();
            osc.type = type;
            osc.frequency.setValueAtTime(freq, this.audioCtx.currentTime);
            osc.frequency.exponentialRampToValueAtTime(freq * 1.5, this.audioCtx.currentTime + 0.15);
            gain.gain.setValueAtTime(0.12, this.audioCtx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, this.audioCtx.currentTime + 0.35);
            osc.connect(gain);
            gain.connect(this.audioCtx.destination);
            osc.start();
            osc.stop(this.audioCtx.currentTime + 0.36);
        } catch (e) {}
    },

    checkInitialSession() {
        const currentUser = MPCStore.getCurrentUser();
        if (currentUser) {
            this.authBtnText.textContent = currentUser.name ? `${currentUser.name} (✓ Verified)` : `${currentUser.phone}`;
            this.userAuthBtn.classList.add('btn-primary');
            this.bookingCustomerPhone.value = currentUser.phone;
            this.phoneVerifyBadge.classList.add('verified');
            this.phoneVerifyBadge.textContent = '✓ Verified';
            const nameInput = document.getElementById('cust-name');
            if (nameInput && currentUser.name) nameInput.value = currentUser.name;
        } else {
            this.authBtnText.textContent = 'Customer Login';
            this.userAuthBtn.classList.remove('btn-primary');
            this.phoneVerifyBadge.classList.remove('verified');
            this.phoneVerifyBadge.textContent = 'Verify via OTP';
        }
    },

    setPropertyType(type) {
        this.selectedPropertyType = type;
        if (type === 'household') {
            this.premiseHouseholdBtn.classList.add('active');
            this.premiseCommercialBtn.classList.remove('active');
            this.commercialFieldGroup.style.display = 'none';
            this.propertySizeLabel.textContent = 'Apartment / House Size';
            document.getElementById('property-size').innerHTML = `
                <option value="1 BHK (450-600 sq.ft)">1 BHK (450-600 sq.ft)</option>
                <option value="2 BHK (700-1000 sq.ft)" selected>2 BHK (700-1000 sq.ft)</option>
                <option value="3 BHK (1100-1500 sq.ft)">3 BHK (1100-1500 sq.ft)</option>
                <option value="4+ BHK / Duplex">4+ BHK / Duplex</option>
                <option value="Independent Villa / Bungalow">Independent Villa / Bungalow</option>
            `;
        } else {
            this.premiseHouseholdBtn.classList.remove('active');
            this.premiseCommercialBtn.classList.add('active');
            this.commercialFieldGroup.style.display = 'flex';
            this.propertySizeLabel.textContent = 'Premises Area (Sq. Ft.)';
            document.getElementById('property-size').innerHTML = `
                <option value="Up to 500 sq.ft (Shop/Cabin)">Up to 500 sq.ft (Shop/Small Office)</option>
                <option value="500 - 1500 sq.ft (Office/Cafe)" selected>500 - 1500 sq.ft (Office/Restaurant)</option>
                <option value="1500 - 3500 sq.ft (Commercial Space)">1500 - 3500 sq.ft (Commercial)</option>
                <option value="3500 - 10000 sq.ft (Warehouse/Factory)">3500 - 10000 sq.ft (Godown/Factory)</option>
                <option value="10000+ sq.ft (Industrial Complex)">10000+ sq.ft (Industrial Complex)</option>
            `;
        }
    },

    renderPestOptions() {
        const container = document.getElementById('pest-cards-container');
        if (!container) return;
        container.innerHTML = '';

        PEST_TYPES.forEach(pest => {
            const isSelected = pest.id === this.selectedPest;
            const card = document.createElement('div');
            card.className = `pest-card ${isSelected ? 'selected' : ''}`;
            card.dataset.id = pest.id;

            card.innerHTML = `
                <div class="pest-card-top">
                    <div class="pest-header-row">
                        <div class="pest-icon-wrap">${pest.icon}</div>
                        <span class="amc-chip">1-Year Warranty Included</span>
                    </div>
                    <h3>${pest.name}</h3>
                    <div class="pest-local-name">${pest.localName}</div>
                    <p class="pest-desc">${pest.description}</p>
                    <ul class="pest-treatments-list">
                        ${pest.treatmentMethods.map(m => `<li><span>✓</span> ${m}</li>`).join('')}
                    </ul>
                </div>
                <div class="pest-card-footer">
                    <div class="pest-price-tag">
                        <span class="price-sub">Starting from</span>
                        <span class="price-val">₹${pest.basePrice.toLocaleString()}</span>
                    </div>
                    <button type="button" class="btn-primary" style="padding: 7px 16px; font-size: 0.82rem;">
                        ${isSelected ? 'Selected ✓' : 'Select'}
                    </button>
                </div>
            `;

            card.addEventListener('click', () => {
                document.querySelectorAll('.pest-card').forEach(c => c.classList.remove('selected'));
                card.classList.add('selected');
                this.selectedPest = pest.id;
                const bookPestSelect = document.getElementById('booking-pest-select');
                if (bookPestSelect) bookPestSelect.value = pest.id;
                this.playChime(480);
            });

            container.appendChild(card);
        });

        // Also sync the dropdown in booking form
        const bookPestSelect = document.getElementById('booking-pest-select');
        if (bookPestSelect) {
            bookPestSelect.innerHTML = PEST_TYPES.map(p => `
                <option value="${p.id}" ${p.id === this.selectedPest ? 'selected' : ''}>
                    ${p.icon} ${p.name} - ₹${p.basePrice}
                </option>
            `).join('');

            bookPestSelect.addEventListener('change', (e) => {
                this.selectedPest = e.target.value;
                document.querySelectorAll('.pest-card').forEach(c => {
                    c.classList.toggle('selected', c.dataset.id === this.selectedPest);
                });
            });
        }
    },

    // Strict Rule: Max 2 slots per day across the business
    updateDateAndSlotsAvailability(dateStr) {
        const availability = MPCStore.getSlotAvailability(dateStr);

        // Update Hero Preview
        if (this.heroDateLabel) {
            this.heroDateLabel.textContent = dateStr === formatDate(new Date()) ? `Today (${dateStr})` : dateStr;
        }

        const todayAvail = MPCStore.getSlotAvailability(formatDate(new Date()));
        if (this.heroMorningStatus) {
            this.heroMorningStatus.textContent = todayAvail.morning.isAvailable ? 'Available' : 'Booked';
            this.heroMorningStatus.className = todayAvail.morning.isAvailable ? 'slot-badge-avail' : 'slot-badge-booked';
        }
        if (this.heroEveningStatus) {
            this.heroEveningStatus.textContent = todayAvail.evening.isAvailable ? 'Available' : 'Booked';
            this.heroEveningStatus.className = todayAvail.evening.isAvailable ? 'slot-badge-avail' : 'slot-badge-booked';
        }

        // Update Booking Section
        if (this.slotsRemainingBadge) {
            this.slotsRemainingBadge.textContent = `${availability.slotsRemaining} of 2 Slots Available`;
            this.slotsRemainingBadge.style.background = availability.slotsRemaining > 0 ? '#ecfdf5' : '#fee2e2';
            this.slotsRemainingBadge.style.color = availability.slotsRemaining > 0 ? '#065f46' : '#991b1b';
        }

        // Morning Slot
        if (availability.morning.isAvailable) {
            this.slotMorningCard.classList.remove('disabled');
            this.slotMorningStatus.textContent = 'Available';
            this.slotMorningStatus.className = 'slot-badge slot-badge-avail';
        } else {
            this.slotMorningCard.classList.add('disabled');
            this.slotMorningStatus.textContent = 'Booked';
            this.slotMorningStatus.className = 'slot-badge slot-badge-booked';
            if (this.selectedSlot === 'morning') this.selectedSlot = 'evening';
        }

        // Evening Slot
        if (availability.evening.isAvailable) {
            this.slotEveningCard.classList.remove('disabled');
            this.slotEveningStatus.textContent = 'Available';
            this.slotEveningStatus.className = 'slot-badge slot-badge-avail';
        } else {
            this.slotEveningCard.classList.add('disabled');
            this.slotEveningStatus.textContent = 'Booked';
            this.slotEveningStatus.className = 'slot-badge slot-badge-booked';
            if (this.selectedSlot === 'evening') this.selectedSlot = 'morning';
        }

        // Fully Booked Check
        if (availability.isFullyBooked) {
            this.fullyBookedWarning.style.display = 'flex';
            this.bookingSubmitBtn.disabled = true;
            this.bookingSubmitBtn.style.opacity = '0.5';
            this.bookingSubmitBtn.textContent = 'Date Fully Booked (2/2 Slots Filled)';
            this.slotMorningCard.classList.remove('selected');
            this.slotEveningCard.classList.remove('selected');
        } else {
            this.fullyBookedWarning.style.display = 'none';
            this.bookingSubmitBtn.disabled = false;
            this.bookingSubmitBtn.style.opacity = '1';
            this.bookingSubmitBtn.textContent = 'Confirm Inspection Booking';
            this.selectSlot(this.selectedSlot);
        }
    },

    selectSlot(slotTime) {
        this.selectedSlot = slotTime;
        if (slotTime === 'morning' && !this.slotMorningCard.classList.contains('disabled')) {
            this.slotMorningCard.classList.add('selected');
            this.slotEveningCard.classList.remove('selected');
        } else if (slotTime === 'evening' && !this.slotEveningCard.classList.contains('disabled')) {
            this.slotEveningCard.classList.add('selected');
            this.slotMorningCard.classList.remove('selected');
        }
    },

    // Handle Inspection Booking Submission
    handleBookingSubmission() {
        const custName = document.getElementById('cust-name').value.trim();
        const custPhone = document.getElementById('cust-phone').value.trim();
        const custCity = document.getElementById('cust-city').value;
        const custAddress = document.getElementById('cust-address').value.trim();
        const propertySize = document.getElementById('property-size').value;
        const pestId = document.getElementById('booking-pest-select').value;
        const specialNotes = document.getElementById('cust-notes').value.trim();
        const commercialName = document.getElementById('comm-business-name')?.value.trim();

        if (!custName || !custPhone || !custAddress) {
            alert('Please fill all required fields (Name, Contact No, and Address).');
            return;
        }

        if (!/^[6-9]\d{9}$/.test(custPhone)) {
            alert('Please enter a valid 10-digit Indian Mobile Number.');
            return;
        }

        // Verify slot availability
        const availability = MPCStore.getSlotAvailability(this.selectedDate);
        if (availability.isFullyBooked) {
            alert('Sorry, both slots for this date are already booked! Please select another date.');
            return;
        }

        if (this.selectedSlot === 'morning' && !availability.morning.isAvailable) {
            alert('The morning slot is already booked. Please select the evening slot.');
            return;
        }

        if (this.selectedSlot === 'evening' && !availability.evening.isAvailable) {
            alert('The evening slot is already booked. Please select the morning slot.');
            return;
        }

        const pestObj = PEST_TYPES.find(p => p.id === pestId) || PEST_TYPES[0];

        // Prepare Booking Payload
        const bookingId = `MPC-BK-${Math.floor(1000 + Math.random() * 9000)}`;
        const expiryDate = new Date(this.selectedDate);
        expiryDate.setFullYear(expiryDate.getFullYear() + 1);

        const bookingPayload = {
            id: bookingId,
            customerName: this.selectedPropertyType === 'commercial' && commercialName ? `${custName} (${commercialName})` : custName,
            phone: custPhone,
            customerType: this.selectedPropertyType,
            propertyDetails: `${propertySize} - ${this.selectedPropertyType.toUpperCase()}`,
            address: custAddress,
            city: custCity,
            pestType: pestObj.id,
            pestName: pestObj.name,
            bookingDate: this.selectedDate,
            slotTime: this.selectedSlot,
            slotLabel: this.selectedSlot === 'morning' ? 'Morning Slot (10:00 AM - 01:00 PM)' : 'Evening Slot (03:00 PM - 06:00 PM)',
            status: 'confirmed',
            amount: pestObj.basePrice,
            paymentStatus: this.selectedPaymentMode === 'prepay_upi' ? 'paid' : 'at_inspection',
            paymentMethod: this.selectedPaymentMode === 'prepay_upi' ? 'UPI to 7208102567' : 'Pay After Inspection',
            transactionId: this.selectedPaymentMode === 'prepay_upi' ? `TXN-MPC-${Date.now().toString().slice(-6)}` : 'PENDING-VISIT',
            serviceStartDate: this.selectedDate,
            validityExpiryDate: formatDate(expiryDate),
            warrantyActive: true,
            notes: specialNotes || 'Customer online slot booking.',
            serviceTrackRecord: [
                {
                    date: this.selectedDate,
                    event: `Inspection & ${pestObj.name} Treatment Slot Confirmed`,
                    technician: 'Harshal Satkar (Maharashtra Pest Control)'
                }
            ]
        };

        // Check if customer phone is verified
        const currentUser = MPCStore.getCurrentUser();
        if (!currentUser || currentUser.phone !== custPhone) {
            // Require Real-time OTP
            this.pendingBookingPayload = bookingPayload;
            this.openOtpModal('booking_verify', custPhone);
        } else {
            // Directly complete booking
            this.finalizeBooking(bookingPayload);
        }
    },

    finalizeBooking(payload) {
        MPCStore.addBooking(payload);

        // If prepay was selected, log payment record for admin phone 7208102567
        if (payload.paymentStatus === 'paid') {
            MPCStore.addPayment({
                id: payload.transactionId,
                bookingId: payload.id,
                customerName: payload.customerName,
                customerPhone: payload.phone,
                amount: payload.amount,
                method: payload.paymentMethod,
                adminPhone: COMPANY_INFO.phone,
                status: 'SUCCESS',
                date: `${formatDate(new Date())} ${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`,
                utr: `UTR-${Math.floor(100000 + Math.random() * 900000)}`,
                note: `Pre-payment received for ${payload.pestName}`
            });
        }

        this.playChime(750);
        this.updateDateAndSlotsAvailability(this.selectedDate);
        this.renderAdminDashboard();

        // If pre-pay selected, show UPI QR modal; otherwise show success warranty confirmation
        if (this.selectedPaymentMode === 'prepay_upi') {
            this.openPaymentQrModal(payload);
        } else {
            this.displayBookingSuccessModal(payload);
        }
    },

    displayBookingSuccessModal(booking) {
        const modal = document.getElementById('success-booking-modal');
        if (!modal) return;
        document.getElementById('success-booking-id').textContent = booking.id;
        document.getElementById('success-slot-label').textContent = `${booking.bookingDate} • ${booking.slotLabel}`;
        document.getElementById('success-warranty-expiry').textContent = booking.validityExpiryDate;

        modal.classList.add('active');

        // Scroll and render warranty card for immediate reassurance
        this.renderWarrantyCard(booking);
    },

    openPaymentQrModal(booking) {
        this.payModalAmount.textContent = `₹${booking.amount.toLocaleString()}`;
        this.payModalBookingId.textContent = booking.id;
        this.paymentModal.classList.add('active');

        // Provide button to simulate payment completion
        const confirmBtn = document.getElementById('payment-complete-btn');
        confirmBtn.onclick = () => {
            this.paymentModal.classList.remove('active');
            this.displayBookingSuccessModal(booking);
            this.showToast('Pre-payment recorded and verified successfully!');
        };
    },

    // Real-Time OTP Engine
    openOtpModal(type, phone) {
        this.pendingOtpType = type;
        this.pendingOtpPhone = phone || (type === 'admin_login' ? COMPANY_INFO.phone : '9820112233');

        // Generate 4 digit OTP
        const otpCode = Math.floor(1000 + Math.random() * 9000);
        this.pendingOtp = otpCode;

        this.otpInput1.value = '';
        this.otpInput2.value = '';
        this.otpInput3.value = '';
        this.otpInput4.value = '';

        if (type === 'admin_login') {
            this.otpModalTitle.textContent = 'Admin Verification OTP';
            this.otpModalPhone.textContent = `Sent to Harshal Satkar (+91 ${COMPANY_INFO.phone})`;
        } else {
            this.otpModalTitle.textContent = 'Customer Verification OTP';
            this.otpModalPhone.textContent = `Sent to +91 ${this.pendingOtpPhone}`;
        }

        this.otpModal.classList.add('active');
        this.otpInput1.focus();

        // Simulate Real-time SMS Toast Banner
        this.triggerRealTimeSmsBanner(this.pendingOtpPhone, otpCode, type);
    },

    triggerRealTimeSmsBanner(phone, otp, type) {
        const isOwner = type === 'admin_login';
        this.smsRecipient.textContent = isOwner ? `Harshal Satkar (+91 ${phone})` : `+91 ${phone}`;
        this.smsMessage.innerHTML = isOwner
            ? `Maharashtra Pest Control Admin Alert: Your secure access code is <span class="sms-otp-highlight">${otp}</span>. Valid for 10 mins.`
            : `Maharashtra Pest Control: Your verification OTP is <span class="sms-otp-highlight">${otp}</span>. Book inspection & 1-Year AMC with Harshal Satkar.`;

        this.smsToast.classList.add('show');
        this.playChime(640);

        // Auto hide banner after 12 seconds
        setTimeout(() => {
            this.smsToast.classList.remove('show');
        }, 12000);
    },

    verifyEnteredOtp() {
        const entered = `${this.otpInput1.value}${this.otpInput2.value}${this.otpInput3.value}${this.otpInput4.value}`;
        if (entered.length !== 4) {
            alert('Please enter 4-digit OTP.');
            return;
        }

        if (parseInt(entered, 10) !== this.pendingOtp) {
            alert('Invalid OTP. Please check the simulated SMS toast or click Autofill.');
            return;
        }

        // OTP Verified!
        this.otpModal.classList.remove('active');
        this.smsToast.classList.remove('show');
        this.playChime(880);

        if (this.pendingOtpType === 'admin_login') {
            MPCStore.setAdminLoggedIn(true);
            this.switchPortal('admin');
            this.showToast('Admin verification successful! Welcome Harshal Satkar.');
        } else if (this.pendingOtpType === 'booking_verify') {
            const userName = document.getElementById('cust-name').value;
            MPCStore.setCurrentUser({
                name: userName,
                phone: this.pendingOtpPhone,
                verified: true
            });
            this.checkInitialSession();
            if (this.pendingBookingPayload) {
                this.finalizeBooking(this.pendingBookingPayload);
                this.pendingBookingPayload = null;
            }
        } else if (this.pendingOtpType === 'user_login') {
            MPCStore.setCurrentUser({
                name: 'Verified Customer',
                phone: this.pendingOtpPhone,
                verified: true
            });
            this.checkInitialSession();
            this.showToast('Login successful!');
        }
    },

    requestAdminAccess() {
        if (MPCStore.isAdminLoggedIn()) {
            this.switchPortal('admin');
        } else {
            // Require OTP sent to Harshal Satkar (7208102567)
            this.openOtpModal('admin_login', COMPANY_INFO.phone);
        }
    },

    switchPortal(mode) {
        this.currentMode = mode;
        if (mode === 'admin') {
            this.customerView.classList.add('hidden-view');
            this.adminView.classList.remove('hidden-view');
            this.portalSwitchBtn.classList.add('active-admin');
            this.portalSwitchText.textContent = '← Customer View';
            this.renderAdminDashboard();
            window.scrollTo({ top: 0, behavior: 'smooth' });
        } else {
            this.customerView.classList.remove('hidden-view');
            this.adminView.classList.add('hidden-view');
            this.portalSwitchBtn.classList.remove('active-admin');
            this.portalSwitchText.textContent = 'Admin Portal (Harshal Satkar)';
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }
    },

    // 1-Year Validity AMC Lookup & Card Rendering
    handleWarrantyLookup() {
        const query = this.amcSearchInput.value.trim().toLowerCase();
        if (!query) {
            alert('Please enter your Mobile Number or Booking/AMC ID.');
            return;
        }

        const bookings = MPCStore.getBookings();
        const found = bookings.find(b =>
            (b.phone && b.phone.includes(query)) ||
            (b.id && b.id.toLowerCase().includes(query))
        );

        if (!found) {
            alert(`No active booking or 1-Year AMC found for "${query}". Please check the phone number or book a new slot.`);
            return;
        }

        this.renderWarrantyCard(found);
        this.warrantyResultContainer.scrollIntoView({ behavior: 'smooth' });
    },

    renderWarrantyCard(booking) {
        const container = this.warrantyResultContainer;
        if (!container) return;

        const now = new Date();
        const expDate = new Date(booking.validityExpiryDate);
        const diffTime = expDate - now;
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        const isExpired = diffDays < 0;
        const isExpiringSoon = diffDays >= 0 && diffDays <= 30;

        let statusText = 'ACTIVE WARRANTY';
        let statusClass = 'warranty-status-pill';
        if (isExpired) {
            statusText = 'WARRANTY EXPIRED';
            statusClass = 'warranty-status-pill expired';
        } else if (isExpiringSoon) {
            statusText = `EXPIRING IN ${diffDays} DAYS`;
            statusClass = 'warranty-status-pill expiring';
        }

        container.innerHTML = `
            <div class="warranty-display-card">
                <div class="warranty-card-header">
                    <div class="warranty-cert-title">
                        <h4>Maharashtra Pest Control • AMC Guarantee Card</h4>
                        <h3>1-Year Comprehensive Service Certificate</h3>
                    </div>
                    <div class="${statusClass}">
                        <span>●</span> ${statusText}
                    </div>
                </div>

                <div class="warranty-grid-details">
                    <div>
                        <div class="w-detail-label">Customer Name</div>
                        <div class="w-detail-val">${booking.customerName}</div>
                    </div>
                    <div>
                        <div class="w-detail-label">Certificate / AMC No</div>
                        <div class="w-detail-val">${booking.id}</div>
                    </div>
                    <div>
                        <div class="w-detail-label">Treated Pest</div>
                        <div class="w-detail-val">${booking.pestName}</div>
                    </div>
                    <div>
                        <div class="w-detail-label">Service Premise</div>
                        <div class="w-detail-val">${booking.city} (${booking.customerType.toUpperCase()})</div>
                    </div>
                    <div>
                        <div class="w-detail-label">Start Date</div>
                        <div class="w-detail-val">${booking.serviceStartDate || booking.bookingDate}</div>
                    </div>
                    <div>
                        <div class="w-detail-label">1-Year Expiry Date</div>
                        <div class="w-detail-val" style="color: #fbbf24;">${booking.validityExpiryDate}</div>
                    </div>
                    <div>
                        <div class="w-detail-label">Proprietor</div>
                        <div class="w-detail-val">Harshal Satkar</div>
                    </div>
                    <div>
                        <div class="w-detail-label">Govt Approved Chemicals</div>
                        <div class="w-detail-val">Bayer / Premise (Odourless)</div>
                    </div>
                </div>

                <div class="w-countdown-banner">
                    <div>
                        <span style="font-size: 0.8rem; color: rgba(255,255,255,0.7); text-transform: uppercase;">Validity Remaining</span>
                        <div class="countdown-digits">
                            ${isExpired ? '0 Days (Expired)' : `${diffDays} Days Remaining`}
                        </div>
                    </div>
                    <div style="display: flex; gap: 10px; align-items: center;">
                        <a href="https://wa.me/91${COMPANY_INFO.phone}?text=Hi%20Harshal%20Satkar,%20I%20have%20an%20active%201-Year%20AMC%20(${booking.id})%20and%20would%20like%20to%20request%20a%20free%20recall%20service."
                           target="_blank" class="btn-whatsapp" style="font-size: 0.8rem; padding: 8px 14px;">
                            💬 Request Free AMC Recall
                        </a>
                        <button onclick="window.print()" class="btn-outline" style="border-color: rgba(255,255,255,0.3); color: white; padding: 7px 14px; font-size: 0.8rem;">
                            🖨️ Print Certificate
                        </button>
                    </div>
                </div>
            </div>

            <!-- Service Track Record Timeline -->
            <div class="timeline-card">
                <h4>📋 1-Year Service History & Track Record (${booking.customerName})</h4>
                <div class="timeline-list">
                    ${(booking.serviceTrackRecord || [
                        { date: booking.bookingDate, event: 'Inspection & Slot Booking Confirmed', technician: 'Harshal Satkar' }
                    ]).map(record => `
                        <div class="timeline-node">
                            <div class="timeline-marker"></div>
                            <div class="timeline-content-box">
                                <span class="timeline-date">${record.date}</span>
                                <div class="timeline-title">${record.event}</div>
                                <div class="timeline-tech">Lead Technician: <strong>${record.technician || 'Harshal Satkar'}</strong> • Contact: 7208102567</div>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        `;
    },

    // Admin Dashboard Rendering
    renderAdminDashboard() {
        const bookings = MPCStore.getBookings();
        const payments = MPCStore.getPayments();
        const feedbacks = MPCStore.getFeedbacks();
        const expiringList = MPCStore.getExpiringCustomers();

        // 1. Metric Counts
        if (this.adminBookingsCount) this.adminBookingsCount.textContent = bookings.length;
        if (this.adminActiveAmcCount) {
            const active = bookings.filter(b => b.warrantyActive && new Date(b.validityExpiryDate) >= new Date()).length;
            this.adminActiveAmcCount.textContent = active;
        }
        if (this.adminPaymentsCount) {
            const totalPaid = payments.reduce((sum, p) => sum + (p.amount || 0), 0);
            this.adminPaymentsCount.textContent = `₹${totalPaid.toLocaleString()}`;
        }
        if (this.adminTodaySlotsCount) {
            const todayStr = formatDate(new Date());
            const todayBooked = bookings.filter(b => b.bookingDate === todayStr && b.status !== 'cancelled').length;
            this.adminTodaySlotsCount.textContent = `${todayBooked} / 2 Slots`;
        }

        // Expiry Notification Badge
        if (this.adminExpiryBadge) {
            this.adminExpiryBadge.textContent = expiringList.length;
            this.adminExpiryBadge.style.display = expiringList.length > 0 ? 'inline-block' : 'none';
        }

        // 2. Expiry Alerts Hub (Flag customers whose 1-year validity is expiring)
        this.renderAdminExpiryAlerts(expiringList);

        // 3. Bookings Table
        this.renderAdminBookingsTable(bookings);

        // 4. Pre-Payments Ledger Table
        this.renderAdminPaymentsTable(payments);

        // 5. Customer Feedback Moderation
        this.renderAdminFeedbackTable(feedbacks);
    },

    renderAdminExpiryAlerts(expiringList) {
        const container = this.adminExpiryAlertsContainer;
        const dedicatedList = document.getElementById('admin-expiries-list');

        if (!container && !dedicatedList) return;

        let html = '';
        if (expiringList.length === 0) {
            html = `
                <div style="background: white; border-radius: 8px; padding: 20px; text-align: center; color: var(--slate-500); border: 1px solid var(--slate-200);">
                    ✅ No customer 1-year warranties expiring within the next 30 days! All client accounts are up to date.
                </div>
            `;
        } else {
            html = expiringList.map(item => {
                const isExp = item.isExpired;
                const waMsg = encodeURIComponent(
                    `Hello ${item.customerName}, your 1-Year Pest Control AMC with Maharashtra Pest Control (Harshal Satkar) for ${item.pestName} is expiring on ${item.validityExpiryDate}. Contact 7208102567 to renew with an exclusive 15% loyalty discount and keep your premises pest-free!`
                );

                return `
                    <div class="expiry-card-item ${isExp ? 'expired-badge-border' : ''}">
                        <div>
                            <div class="exp-badge-row">
                                <span style="font-size: 0.75rem; font-weight: 700; color: var(--slate-600);">${item.id}</span>
                                <span class="exp-days-badge ${isExp ? '' : 'warning'}">
                                    ${isExp ? `Expired ${Math.abs(item.daysRemaining)} days ago` : `Expiring in ${item.daysRemaining} days`}
                                </span>
                            </div>
                            <div class="expiry-client-name">${item.customerName} (${item.phone})</div>
                            <div class="expiry-client-address">${item.address}, ${item.city} • <strong>${item.pestName}</strong></div>
                            <div style="font-size: 0.78rem; color: var(--slate-600);">
                                Expiry Date: <strong>${item.validityExpiryDate}</strong>
                            </div>
                        </div>

                        <div class="exp-actions-row">
                            <a href="https://wa.me/91${item.phone}?text=${waMsg}" target="_blank" class="btn-whatsapp" style="font-size: 0.74rem; padding: 6px 10px;">
                                💬 Send WhatsApp Renewal
                            </a>
                            <a href="tel:${item.phone}" class="btn-outline" style="font-size: 0.74rem; padding: 6px 10px;">
                                📞 Call Client
                            </a>
                            <button onclick="MPCApp.extendCustomerValidity('${item.id}')" class="btn-table-action" style="background: #ecfdf5; color: #065f46; border-color: #a7f3d0;">
                                🔄 Renew 1-Year AMC
                            </button>
                        </div>
                    </div>
                `;
            }).join('');
        }

        if (container) container.innerHTML = html;
        if (dedicatedList) dedicatedList.innerHTML = `<div class="expiry-cards-slider">${html}</div>`;
    },

    extendCustomerValidity(bookingId) {
        const bookings = MPCStore.getBookings();
        const booking = bookings.find(b => b.id === bookingId);
        if (!booking) return;

        if (confirm(`Extend 1-Year AMC for ${booking.customerName} until next year?`)) {
            const newExp = new Date();
            newExp.setFullYear(newExp.getFullYear() + 1);
            const expDateStr = formatDate(newExp);

            const updatedHistory = booking.serviceTrackRecord || [];
            updatedHistory.push({
                date: formatDate(new Date()),
                event: `1-Year AMC Renewed for another 365 days by Harshal Satkar`,
                technician: 'Harshal Satkar (Owner)'
            });

            MPCStore.updateBooking(bookingId, {
                validityExpiryDate: expDateStr,
                warrantyActive: true,
                serviceTrackRecord: updatedHistory
            });

            this.showToast(`1-Year AMC extended for ${booking.customerName} until ${expDateStr}!`);
            this.renderAdminDashboard();
        }
    },

    renderAdminBookingsTable(bookings) {
        const tbody = this.adminBookingsTableBody;
        if (!tbody) return;

        tbody.innerHTML = bookings.map(b => `
            <tr>
                <td><strong>${b.id}</strong></td>
                <td>
                    <div style="font-weight: 700;">${b.customerName}</div>
                    <div style="font-size: 0.75rem; color: var(--slate-500);">${b.phone}</div>
                </td>
                <td>
                    <span class="status-tag ${b.customerType === 'commercial' ? 'status-pending' : 'status-confirmed'}">
                        ${b.customerType === 'commercial' ? '🏢 Commercial' : '🏠 Household'}
                    </span>
                    <div style="font-size: 0.75rem; margin-top: 2px;">${b.city}</div>
                </td>
                <td>
                    <div style="font-weight: 600;">${b.pestName}</div>
                </td>
                <td>
                    <div>${b.bookingDate}</div>
                    <div style="font-size: 0.74rem; color: var(--slate-500);">${b.slotLabel}</div>
                </td>
                <td>
                    <span class="status-tag status-${b.status}">${b.status.toUpperCase()}</span>
                </td>
                <td>
                    <div style="font-weight: 700;">₹${b.amount}</div>
                    <div style="font-size: 0.72rem; color: ${b.paymentStatus === 'paid' ? '#16a34a' : '#d97706'}; font-weight: 700;">
                        ${b.paymentStatus.toUpperCase()}
                    </div>
                </td>
                <td>
                    <div class="action-btn-group">
                        <a href="https://wa.me/91${b.phone}?text=Hello%20${encodeURIComponent(b.customerName)},%20this%20is%20Harshal%20Satkar%20from%20Maharashtra%20Pest%20Control%20regarding%20your%20booking%20${b.id}."
                           target="_blank" class="btn-table-action" title="WhatsApp Customer">💬</a>
                        <a href="tel:${b.phone}" class="btn-table-action" title="Call Customer">📞</a>
                        <button onclick="MPCApp.updateBookingStatus('${b.id}', 'completed')" class="btn-table-action" title="Mark Completed">✓</button>
                    </div>
                </td>
            </tr>
        `).join('');
    },

    updateBookingStatus(id, newStatus) {
        MPCStore.updateBooking(id, { status: newStatus });
        this.showToast(`Booking ${id} marked as ${newStatus}`);
        this.renderAdminDashboard();
    },

    renderAdminPaymentsTable(payments) {
        const tbody = this.adminPaymentsTableBody;
        if (!tbody) return;

        tbody.innerHTML = payments.map(p => `
            <tr>
                <td><strong>${p.id}</strong></td>
                <td>
                    <div style="font-weight: 700;">${p.customerName}</div>
                    <div style="font-size: 0.74rem; color: var(--slate-500);">${p.customerPhone}</div>
                </td>
                <td><strong>₹${p.amount}</strong></td>
                <td>${p.method}</td>
                <td><span style="font-family: monospace; font-size: 0.78rem;">${p.adminPhone}</span> (Harshal Satkar)</td>
                <td>${p.date}</td>
                <td>
                    <span class="status-tag status-confirmed">SUCCESS</span>
                </td>
            </tr>
        `).join('');
    },

    renderAdminFeedbackTable(feedbacks) {
        const tbody = this.adminFeedbackTableBody;
        if (!tbody) return;

        tbody.innerHTML = feedbacks.map(f => `
            <tr>
                <td><strong>${f.id || 'FB'}</strong></td>
                <td>${f.name} (${f.area || 'Mumbai'})</td>
                <td>${f.pestTreated || 'Pest Control'}</td>
                <td style="color: #f59e0b; font-weight: 700;">★ ${f.rating}/5</td>
                <td style="max-width: 300px; font-size: 0.82rem;">"${f.comment}"</td>
                <td>${f.date || 'Recent'}</td>
            </tr>
        `).join('');
    },

    // Customer Feedback Handling
    handleFeedbackSubmission() {
        const name = document.getElementById('fb-name').value.trim();
        const phone = document.getElementById('fb-phone').value.trim();
        const area = document.getElementById('fb-area').value.trim();
        const pest = document.getElementById('fb-pest').value;
        const comment = document.getElementById('fb-comment').value.trim();

        if (!name || !comment) {
            alert('Please provide your name and review comments.');
            return;
        }

        const newFeedback = {
            id: `FB-${Math.floor(100 + Math.random() * 900)}`,
            name,
            phone: phone ? `${phone.slice(0, 4)}******` : '9820******',
            area: area || 'Mumbai',
            customerType: 'Verified Customer',
            pestTreated: pest,
            rating: this.selectedRating,
            date: formatDate(new Date()),
            comment,
            verified: true
        };

        MPCStore.addFeedback(newFeedback);
        this.playChime(720);
        this.renderReviewsList();
        this.renderAdminDashboard();
        this.feedbackForm.reset();
        this.showToast('Thank you! Your feedback has been published.');
    },

    renderReviewsList() {
        const container = document.getElementById('reviews-list-container');
        if (!container) return;

        const feedbacks = MPCStore.getFeedbacks();
        container.innerHTML = feedbacks.map(f => `
            <div class="review-item-card">
                <div class="review-card-top">
                    <div class="review-author">
                        <h4>${f.name} <span class="verified-icon" title="Verified Customer">✓ Verified</span></h4>
                    </div>
                    <div class="review-stars">${'★'.repeat(f.rating)}${'☆'.repeat(5 - f.rating)}</div>
                </div>
                <div class="review-meta">
                    📍 ${f.area} • Treatment: <strong>${f.pestTreated}</strong> • ${f.date}
                </div>
                <p class="review-text">"${f.comment}"</p>
            </div>
        `).join('');
    },

    showToast(message) {
        const toast = document.createElement('div');
        toast.style.cssText = `
            position: fixed;
            bottom: 30px;
            left: 50%;
            transform: translateX(-50%);
            background: #0f172a;
            color: #ffffff;
            padding: 12px 24px;
            border-radius: 9999px;
            font-size: 0.88rem;
            font-weight: 700;
            box-shadow: 0 10px 25px rgba(0,0,0,0.3);
            z-index: 9999;
            transition: all 0.3s ease;
        `;
        toast.textContent = message;
        document.body.appendChild(toast);
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => toast.remove(), 300);
        }, 3500);
    }
};

window.MPCApp = MPCApp;
